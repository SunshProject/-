# Inventory — учёт расположения инструментов

Android-приложение (Kotlin, SQLite, ZXing). Интерфейс на русском, работает без интернета.

## Как получить Inventory.apk (без установки Android Studio)
1. Создайте пустой репозиторий на github.com и загрузите в него содержимое этой папки (вместе с папкой `.github`).
2. Откройте вкладку **Actions** → **Build Inventory.apk** → **Run workflow** (запускается и сам при загрузке).
3. Через 3–5 минут откройте завершённый запуск и скачайте артефакт **Inventory-apk** — внутри `Inventory.apk`.
4. Скопируйте файл на телефон и установите (разрешите установку из неизвестных источников).

## Локальная сборка
Нужны JDK 17, Android SDK (platform 34) и Gradle 8.7+:
    gradle assembleDebug
APK: `app/build/outputs/apk/debug/app-debug.apk` (переименуйте в Inventory.apk).
Либо откройте папку в Android Studio → Build → Build APK(s).

## Архитектура
`InventoryRepository` — интерфейс хранилища. Сейчас `SqliteRepository` (локальная SQLite).
Для общей серверной БД напишите новую реализацию интерфейса и подставьте её в `MainActivity.onCreate`.
Содержимое полки определяется текущим местоположением предметов, QR хранит только ID полки (SHELF-001).
