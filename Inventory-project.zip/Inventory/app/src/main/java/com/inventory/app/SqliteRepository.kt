package com.inventory.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SqliteRepository(context: Context) :
    SQLiteOpenHelper(context, "inventory.db", null, 1), InventoryRepository {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "sku TEXT NOT NULL DEFAULT ''," +
                "description TEXT NOT NULL DEFAULT ''," +
                "room TEXT NOT NULL DEFAULT ''," +
                "rack TEXT NOT NULL DEFAULT ''," +
                "place TEXT NOT NULL DEFAULT ''," +
                "present INTEGER NOT NULL DEFAULT 1)"
        )
        db.execSQL(
            "CREATE TABLE shelves(" +
                "id TEXT PRIMARY KEY," +
                "room TEXT NOT NULL DEFAULT ''," +
                "rack TEXT NOT NULL DEFAULT ''," +
                "place TEXT NOT NULL DEFAULT '')"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private fun readItem(c: Cursor) = Item(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        name = c.getString(c.getColumnIndexOrThrow("name")),
        sku = c.getString(c.getColumnIndexOrThrow("sku")),
        description = c.getString(c.getColumnIndexOrThrow("description")),
        room = c.getString(c.getColumnIndexOrThrow("room")),
        rack = c.getString(c.getColumnIndexOrThrow("rack")),
        place = c.getString(c.getColumnIndexOrThrow("place")),
        present = c.getInt(c.getColumnIndexOrThrow("present")) == 1
    )

    private fun values(item: Item) = ContentValues().apply {
        put("name", item.name.trim())
        put("sku", item.sku.trim())
        put("description", item.description.trim())
        put("room", item.room.trim())
        put("rack", item.rack.trim())
        put("place", item.place.trim())
        put("present", if (item.present) 1 else 0)
    }

    override fun allItems(): List<Item> {
        val out = ArrayList<Item>()
        readableDatabase.query("items", null, null, null, null, null, "name COLLATE NOCASE").use { c ->
            while (c.moveToNext()) out.add(readItem(c))
        }
        return out.sortedBy { it.name.lowercase() }
    }

    override fun addItem(item: Item): Long = writableDatabase.insert("items", null, values(item))

    override fun updateItem(item: Item) {
        writableDatabase.update("items", values(item), "id=?", arrayOf(item.id.toString()))
    }

    override fun deleteItem(id: Long) {
        writableDatabase.delete("items", "id=?", arrayOf(id.toString()))
    }

    override fun setPresent(id: Long, present: Boolean) {
        val cv = ContentValues().apply { put("present", if (present) 1 else 0) }
        writableDatabase.update("items", cv, "id=?", arrayOf(id.toString()))
    }

    override fun allShelves(): List<Shelf> {
        val out = ArrayList<Shelf>()
        readableDatabase.query("shelves", null, null, null, null, null, "id").use { c ->
            while (c.moveToNext()) {
                out.add(
                    Shelf(
                        c.getString(c.getColumnIndexOrThrow("id")),
                        c.getString(c.getColumnIndexOrThrow("room")),
                        c.getString(c.getColumnIndexOrThrow("rack")),
                        c.getString(c.getColumnIndexOrThrow("place"))
                    )
                )
            }
        }
        return out
    }

    override fun addShelf(shelf: Shelf): Boolean {
        val cv = ContentValues().apply {
            put("id", shelf.id.trim())
            put("room", shelf.room.trim())
            put("rack", shelf.rack.trim())
            put("place", shelf.place.trim())
        }
        return writableDatabase.insert("shelves", null, cv) != -1L
    }

    /** Если у полки меняется название/место, предметы на ней переезжают вместе с ней. */
    override fun updateShelf(old: Shelf, new: Shelf) {
        val moved = itemsOnShelf(old)
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues().apply {
                put("room", new.room.trim())
                put("rack", new.rack.trim())
                put("place", new.place.trim())
            }
            db.update("shelves", cv, "id=?", arrayOf(old.id))
            for (i in moved) updateItem(i.copy(room = new.room, rack = new.rack, place = new.place))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    override fun deleteShelf(id: String) {
        writableDatabase.delete("shelves", "id=?", arrayOf(id))
    }
}
