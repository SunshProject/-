package com.inventory.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.io.File
import java.io.FileOutputStream

private val GREEN = Color.parseColor("#2E7D32")
private val RED = Color.parseColor("#C62828")
private val BLUE = Color.parseColor("#1565C0")
private val DARK = Color.parseColor("#37474F")
private val TEXT = Color.parseColor("#212121")
private val GRAY = Color.parseColor("#616161")
private val BG = Color.parseColor("#F2F2F2")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : AppCompatActivity() {

    private lateinit var repo: InventoryRepository
    private lateinit var root: FrameLayout
    private var backTarget: (() -> Unit)? = null
    private var lastQuery = ""

    private val scanLauncher = registerForActivityResult(ScanContract()) { r ->
        val code = r.contents?.trim().orEmpty()
        if (code.isNotEmpty()) {
            val shelf = repo.findShelf(code)
            if (shelf != null) showShelf(shelf)
            else toast("Полка «$code» не найдена. Добавьте её в разделе ПОЛКИ.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SqliteRepository(applicationContext)
        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val b = backTarget
                if (b != null) b() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        showHome()
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun setScreen(view: View, back: (() -> Unit)?) {
        root.removeAllViews()
        root.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
        backTarget = back
    }

    private fun lp(top: Int = 8, h: Int = WRAP) =
        LinearLayout.LayoutParams(MATCH, h).apply { topMargin = dp(top) }

    private fun column(pad: Int = 16) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    private fun rounded(color: Int, radius: Int = 14, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun tv(text: String, size: Float = 16f, color: Int = TEXT, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun btn(label: String, color: Int, size: Float = 18f, onClick: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = size
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(color)
            minimumHeight = dp(60)
            minHeight = dp(60)
            setOnClickListener { onClick() }
        }

    private fun rowOf(vararg views: View, top: Int = 8) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = lp(top)
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (i > 0) marginStart = dp(8) })
        }
    }

    private fun locationLines(room: String, rack: String, place: String): String {
        val parts = listOf(room, rack, place).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) return "📍 Место не указано"
        return "📍 " + parts.joinToString("\n")
    }

    private fun locationOneLine(room: String, rack: String, place: String) =
        listOf(room, rack, place).map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" / ")

    private fun shelfLabel(s: Shelf) = "${s.id} — ${locationOneLine(s.room, s.rack, s.place)}"

    private fun labeled(form: LinearLayout, label: String, value: String?, multiline: Boolean = false): EditText {
        form.addView(tv(label, 14f, GRAY), lp(10))
        val et = EditText(this).apply {
            textSize = 18f
            setText(value ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or
                (if (multiline) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0) or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            if (multiline) minLines = 2
        }
        form.addView(et, lp(0))
        return et
    }

    // ------------------------------------------------------------------ home

    private fun showHome() {
        val page = column()
        page.addView(tv("INVENTORY", 28f, BLUE, true))

        val search = EditText(this).apply {
            hint = "🔍 Поиск предмета"
            textSize = 18f
            setSingleLine()
            setText(lastQuery)
            background = rounded(Color.WHITE, 12, Color.LTGRAY)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        page.addView(search, lp(8))

        val list = column(0)
        fun refresh() {
            list.removeAllViews()
            val items = repo.search(lastQuery)
            if (items.isEmpty()) {
                list.addView(
                    tv(
                        if (lastQuery.isBlank()) "Пока нет предметов.\nНажмите «➕ Добавить предмет»."
                        else "Ничего не найдено",
                        16f, GRAY
                    ), lp(16)
                )
            } else {
                list.addView(tv("Найдено: ${items.size}", 14f, GRAY), lp(4))
                items.forEach { list.addView(itemCard(it, true) { refresh() }, lp(10)) }
            }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                lastQuery = s?.toString() ?: ""
                refresh()
            }
        })

        page.addView(btn("📷 Сканировать QR полки", BLUE) { scan() }, lp(8))
        page.addView(btn("➕ Добавить предмет", GREEN) { showItemForm(null, null) { refresh() } }, lp(8))
        page.addView(btn("📦 ПОЛКИ", DARK) { showShelves() }, lp(8))

        val scroll = ScrollView(this).apply { addView(list) }
        page.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setScreen(page, null)
        refresh()
    }

    private fun scan() {
        scanLauncher.launch(
            ScanOptions()
                .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("Наведите камеру на QR-код полки")
                .setBeepEnabled(false)
                .setOrientationLocked(false)
        )
    }

    // ------------------------------------------------------------------ item card

    private fun itemCard(item: Item, showLocation: Boolean, refresh: () -> Unit): View {
        val card = column(16)
        card.background = rounded(Color.WHITE, 14, Color.LTGRAY)
        card.addView(tv(item.name, 20f, TEXT, true))
        if (item.sku.isNotBlank()) card.addView(tv("Артикул: ${item.sku}", 15f, GRAY), lp(2))
        if (item.description.isNotBlank()) card.addView(tv(item.description, 15f, GRAY), lp(2))
        if (showLocation) card.addView(tv(locationLines(item.room, item.rack, item.place), 17f), lp(8))

        card.addView(
            if (item.present) tv("🟢 НА МЕСТЕ", 18f, GREEN, true) else tv("🔴 НЕ НА МЕСТЕ", 18f, RED, true),
            lp(8)
        )

        val main = if (item.present)
            btn("ВЗЯТЬ", RED, 20f) { repo.setPresent(item.id, false); refresh() }
        else
            btn("ВЕРНУТЬ", GREEN, 20f) { repo.setPresent(item.id, true); refresh() }
        val edit = btn("✏️", GRAY, 20f) { showItemForm(item, null) { refresh() } }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(10) }
        row.addView(main, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(edit, LinearLayout.LayoutParams(dp(72), WRAP).apply { marginStart = dp(8) })
        card.addView(row)
        return card
    }

    // ------------------------------------------------------------------ item form

    private fun showItemForm(item: Item?, prefill: Shelf?, onDone: () -> Unit) {
        val form = column()
        val name = labeled(form, "Название *", item?.name)
        val sku = labeled(form, "Артикул", item?.sku)
        val desc = labeled(form, "Описание", item?.description, true)
        val room = labeled(form, "Комната", item?.room ?: prefill?.room)
        val rack = labeled(form, "Стеллаж / шкаф", item?.rack ?: prefill?.rack)
        val place = labeled(form, "Полка / ящик / место", item?.place ?: prefill?.place)

        form.addView(btn("📦 Выбрать полку из списка", DARK, 16f) {
            pickShelf { s ->
                room.setText(s.room); rack.setText(s.rack); place.setText(s.place)
            }
        }, lp(14))

        val builder = AlertDialog.Builder(this)
            .setTitle(if (item == null) "Новый предмет" else "Изменить предмет")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("СОХРАНИТЬ", null)
            .setNegativeButton("Отмена", null)
        if (item != null) builder.setNeutralButton("Удалить", null)
        val dlg = builder.create()
        dlg.show()

        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val n = name.text.toString().trim()
            if (n.isEmpty()) {
                name.error = "Введите название"
                return@setOnClickListener
            }
            val result = Item(
                id = item?.id ?: 0,
                name = n,
                sku = sku.text.toString(),
                description = desc.text.toString(),
                room = room.text.toString(),
                rack = rack.text.toString(),
                place = place.text.toString(),
                present = item?.present ?: true
            )
            if (item == null) repo.addItem(result) else repo.updateItem(result)
            dlg.dismiss()
            onDone()
        }
        if (item != null) {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                AlertDialog.Builder(this)
                    .setMessage("Удалить «${item.name}»?")
                    .setPositiveButton("Удалить") { _, _ ->
                        repo.deleteItem(item.id)
                        dlg.dismiss()
                        onDone()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
        }
    }

    private fun pickShelf(onPick: (Shelf) -> Unit) {
        val shelves = repo.allShelves()
        if (shelves.isEmpty()) {
            toast("Сначала добавьте полки в разделе ПОЛКИ")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Выберите полку")
            .setItems(shelves.map { shelfLabel(it) }.toTypedArray()) { _, i -> onPick(shelves[i]) }
            .show()
    }

    // ------------------------------------------------------------------ shelves

    private fun showShelves() {
        val page = column()
        page.addView(tv("📦 ПОЛКИ", 26f, BLUE, true))
        page.addView(btn("➕ ДОБАВИТЬ ПОЛКУ", GREEN) { showShelfForm(null) { showShelves() } }, lp(8))

        val list = column(0)
        val shelves = repo.allShelves()
        if (shelves.isEmpty()) {
            list.addView(tv("Полок пока нет.", 16f, GRAY), lp(16))
        }
        for (s in shelves) {
            val items = repo.itemsOnShelf(s)
            val out = items.count { !it.present }
            val card = column(16)
            card.background = rounded(Color.WHITE, 14, Color.LTGRAY)
            card.addView(tv(s.id, 20f, TEXT, true))
            card.addView(tv(locationLines(s.room, s.rack, s.place), 17f), lp(4))
            card.addView(
                tv("Предметов: ${items.size}" + if (out > 0) "  (🔴 не на месте: $out)" else "", 15f, GRAY),
                lp(4)
            )
            card.addView(
                rowOf(
                    btn("Открыть", BLUE, 16f) { showShelf(s) },
                    btn("QR-код", DARK, 16f) { showShelfQr(s) }
                )
            )
            card.setOnClickListener { showShelf(s) }
            list.addView(card, lp(10))
        }
        page.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setScreen(page) { showHome() }
    }

    private fun showShelf(shelf: Shelf) {
        val page = column()
        page.addView(tv("📦 ${shelf.id}", 24f, BLUE, true))
        page.addView(tv(locationLines(shelf.room, shelf.rack, shelf.place), 19f), lp(4))

        val list = column(0)
        fun refresh() {
            list.removeAllViews()
            val items = repo.itemsOnShelf(shelf)
            list.addView(tv("Содержимое: ${items.size}", 16f, GRAY, true), lp(8))
            if (items.isEmpty()) list.addView(tv("Здесь пока ничего нет.", 16f, GRAY), lp(8))
            items.forEach { list.addView(itemCard(it, false) { refresh() }, lp(10)) }
        }

        page.addView(btn("➕ Добавить предмет сюда", GREEN) { showItemForm(null, shelf) { refresh() } }, lp(10))
        page.addView(
            rowOf(
                btn("QR-код", DARK, 16f) { showShelfQr(shelf) },
                btn("✏️ Изменить", DARK, 16f) {
                    showShelfForm(shelf) { s -> if (s == null) showShelves() else showShelf(s) }
                }
            )
        )
        page.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setScreen(page) { showShelves() }
        refresh()
    }

    private fun showShelfForm(shelf: Shelf?, onDone: (Shelf?) -> Unit) {
        val form = column()
        val room = labeled(form, "Комната", shelf?.room)
        val rack = labeled(form, "Стеллаж / шкаф", shelf?.rack)
        val place = labeled(form, "Полка / ящик", shelf?.place)
        val id = labeled(form, "ID полки", shelf?.id ?: repo.nextShelfCode())
        if (shelf != null) id.isEnabled = false
        else id.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS

        val builder = AlertDialog.Builder(this)
            .setTitle(if (shelf == null) "Новая полка" else "Изменить полку")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("СОХРАНИТЬ", null)
            .setNegativeButton("Отмена", null)
        if (shelf != null) builder.setNeutralButton("Удалить", null)
        val dlg = builder.create()
        dlg.show()

        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (shelf == null) {
                val code = id.text.toString().trim().uppercase().ifEmpty { repo.nextShelfCode() }
                val created = Shelf(code, room.text.toString().trim(), rack.text.toString().trim(), place.text.toString().trim())
                if (!repo.addShelf(created)) {
                    id.error = "Такой ID уже есть"
                    return@setOnClickListener
                }
                dlg.dismiss()
                onDone(created)
                showShelfQr(created)
            } else {
                val updated = Shelf(shelf.id, room.text.toString().trim(), rack.text.toString().trim(), place.text.toString().trim())
                repo.updateShelf(shelf, updated)
                dlg.dismiss()
                onDone(updated)
            }
        }
        if (shelf != null) {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                AlertDialog.Builder(this)
                    .setMessage("Удалить полку ${shelf.id}? Предметы останутся в списке, изменится только регистрация полки и её QR.")
                    .setPositiveButton("Удалить") { _, _ ->
                        repo.deleteShelf(shelf.id)
                        dlg.dismiss()
                        onDone(null)
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
        }
    }

    // ------------------------------------------------------------------ QR

    private fun qrBitmap(text: String, size: Int): Bitmap {
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
        val pixels = IntArray(size * size) { if (matrix[it % size, it / size]) Color.BLACK else Color.WHITE }
        return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
    }

    private fun qrLabelBitmap(shelf: Shelf): Bitmap {
        val w = 800
        val h = 960
        val size = 700
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        c.drawBitmap(qrBitmap(shelf.id, size), (w - size) / 2f, 30f, null)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            textSize = 56f
        }
        c.drawText(shelf.id, w / 2f, 810f, p)
        p.typeface = Typeface.DEFAULT
        val line = locationOneLine(shelf.room, shelf.rack, shelf.place)
        p.textSize = 38f
        while (p.measureText(line) > w - 40 && p.textSize > 16f) p.textSize -= 2f
        c.drawText(line, w / 2f, 880f, p)
        return bmp
    }

    private fun showShelfQr(shelf: Shelf) {
        val bmp = qrLabelBitmap(shelf)
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = ViewGroup.LayoutParams(dp(300), dp(360))
        }
        val holder = FrameLayout(this).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(iv, FrameLayout.LayoutParams(dp(300), dp(360), Gravity.CENTER))
        }
        AlertDialog.Builder(this)
            .setTitle("QR-код полки")
            .setView(holder)
            .setPositiveButton("ПОДЕЛИТЬСЯ / ПЕЧАТЬ") { _, _ -> shareBitmap(bmp, shelf.id) }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun shareBitmap(bmp: Bitmap, id: String) {
        try {
            val dir = File(cacheDir, "qr").apply { mkdirs() }
            val f = File(dir, id.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "QR-код полки"))
        } catch (e: Exception) {
            toast("Не удалось поделиться: ${e.message}")
        }
    }
}
