package com.inventory.app

/**
 * Единственная точка доступа к данным. Чтобы перейти на общую серверную БД,
 * достаточно написать новую реализацию (например, RemoteRepository на REST/Firebase)
 * и подставить её в MainActivity вместо SqliteRepository.
 */
interface InventoryRepository {
    fun allItems(): List<Item>
    fun addItem(item: Item): Long
    fun updateItem(item: Item)
    fun deleteItem(id: Long)
    fun setPresent(id: Long, present: Boolean)

    fun allShelves(): List<Shelf>
    fun addShelf(shelf: Shelf): Boolean
    fun updateShelf(old: Shelf, new: Shelf)
    fun deleteShelf(id: String)

    // ---- Общая логика (не зависит от хранилища) ----

    fun search(query: String): List<Item> {
        val tokens = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val items = allItems()
        if (tokens.isEmpty()) return items
        return items.filter { item ->
            val hay = listOf(item.name, item.sku, item.description, item.room, item.rack, item.place)
                .joinToString(" ").lowercase()
            tokens.all { hay.contains(it) }
        }
    }

    fun findShelf(code: String): Shelf? =
        allShelves().firstOrNull { it.id.equals(code.trim(), ignoreCase = true) }

    /** Содержимое полки определяется текущим местоположением предметов, а не QR-кодом. */
    fun itemsOnShelf(shelf: Shelf): List<Item> = allItems().filter {
        same(it.room, shelf.room) && same(it.rack, shelf.rack) && same(it.place, shelf.place)
    }

    fun nextShelfCode(): String {
        val max = allShelves().mapNotNull {
            Regex("^SHELF-(\\d+)$", RegexOption.IGNORE_CASE).find(it.id)?.groupValues?.get(1)?.toIntOrNull()
        }.maxOrNull() ?: 0
        return "SHELF-%03d".format(max + 1)
    }

    private fun same(a: String, b: String) = a.trim().equals(b.trim(), ignoreCase = true)
}
