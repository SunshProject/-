package com.inventory.app

data class Item(
    val id: Long,
    val name: String,
    val sku: String,
    val description: String,
    val room: String,
    val rack: String,
    val place: String,
    val present: Boolean
)

data class Shelf(
    val id: String,
    val room: String,
    val rack: String,
    val place: String
)
